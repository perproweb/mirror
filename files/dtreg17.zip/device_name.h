char *device_name( unsigned int family );


