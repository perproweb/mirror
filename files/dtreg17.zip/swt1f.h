// swt1f.c include files

// Local subroutines
int SetSwitch1F(HANDLE *,uchar *,int,int,uchar *,int);
int SwitchStateToString1F(int, char *);
int FindBranchDevice(HANDLE *,uchar *,uchar BranchSN[][8],int,int);
int owBranchFirst(HANDLE *,uchar *,int,int);
int owBranchNext(HANDLE *,uchar *,int,int);


